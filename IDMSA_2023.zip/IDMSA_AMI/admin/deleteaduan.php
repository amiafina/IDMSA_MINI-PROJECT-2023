<?php
include('../config.php');
$id=$_GET['id'];
$result = mysqli_query($connect,"DELETE FROM faduan WHERE id='$id'");
header("location:../admin/index.php");
?>