<?php
	include ('../config.php');
?>

<style>
}
.footer{
  background-color: #FDB870;
  padding: 10px;
  text-align: center;
  margin-top: 450px;
}
.footer p{
  color: white;
}
</style>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bungkus</title>
</head>
<body style="font-family: calibri; background-color: lightsalmon;">

	<center>
		<a href="../index.php" style="text-decoration: none;">Log Keluar</a>
		<h2>Data Makanan Bungkus Pelajar Sakit</h2>
		<table cellpadding="5" cellspacing="1" border="1" bgcolor="white">
			<tr style="color:#FF5E24;">
				<th>Nama Pelajar</th>
				<th>Nombor Telefon</th>
				<th>Dorm</th>
				<th>Tindakan</th>
			</tr>

			<?php
			$papar=mysqli_query($connect, "SELECT * FROM pelajar");
			while($row=mysqli_fetch_array($papar)){

				echo "
				<tr>
				<td>".$row['nama_pelajar']."</td>
				<td>".$row['nombor']."</td>
				<td>".$row['dorm']."</td>
				<td >","<a href=\" deletebungkus.php?id=".$row['id']. "\"onClick=\"return confirm('Rekod ini akan dihapuskan')\">Padam</td>
				</tr>
				";
			}
			?>

		</table>

      </center>
<br><br><br><br><br>
		<center>
		<h2>Data Aduan Dewan Makan</h2>
		<table cellpadding="5" cellspacing="1" border="1" bgcolor="white" >
			<tr style="color:#FF5E24;">
				<th>Nama</th>
				<th>Dorm</th>
				<th>Nombor Telefon</th>
				<th>Masa</th>
				<th>Aduan</th>
				<th>Penerangan Aduan</th>
				<th>Cadangan</th>
				<th>Tindakan</th>
			</tr>

			<?php
			$papar=mysqli_query($connect, "SELECT * FROM faduan");
			while($row=mysqli_fetch_array($papar)){

				echo "
				<tr>
				<td>".$row['nama']."</td>
				<td>".$row['dorm']."</td>
				<td>".$row['nombor']."</td>
				<td>".$row['masa']."</td>
				<td>".$row['aduan']."</td>
				<td>".$row['pAduan']."</td>
				<td>".$row['cadangan']."</td>

				<td >","<a href= \" deleteaduan.php?id=".$row['id']. "\"onClick=\"return confirm('Rekod ini akan dihapuskan')\">Padam</td>
				</tr>
				";
			}
			?>

		</table>
		</center>

     <center>
     <div class="footer">
      <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
     </div>
     </center>
     </div>
     </div>
     </center>
</html>