<?php
include('../config.php');
$id=$_GET['id'];
$result = mysqli_query($connect,"DELETE FROM pelajar WHERE id='$id'");
header("location:./admin/index.php");
?>