<style>
  *{
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

body{
  width: 100%;
  height: 210vh;
  background-image: url(./img/bg.png);
  background-size: cover;
  background-position: center;
}
.navbar{  
     width: 85%;
     margin: auto;
     padding: 35px 0;
     display: flex;
     align-items: center;
     justify-content: space-between;
}
.logo{
  width: 250px;
  cursor: pointer;
}
.navbar ul li{
  list-style: none;
  display: inline-block;
  margin: 0 20px;
  position: relative;
}
.navbar ul li a{
  text-decoration: none;
  color: white;
  text-transform: uppercase;

}
.navbar ul li::after{
  content:'';
  height: 3px;
  width: 0%;
  background: orange;
  position: absolute;
  left: 0;
  bottom: -10px;
  transition: 0.5s;
  
}
.navbar ul li:hover::after{
  width: 100%;
}
.content{
  width: 100%;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  text-align: center;
  color: white;
}
.footer{
  background-color: #FDB870;
  padding: 10px;
  text-align: center;
  margin-top: 10px;
}
.footer p{
  color: white;
}
th, td{
    text-align: left;
    padding: 8px;
}

  tr{background-color: #f2f2f2}

  th{
    background-color: orange;color: white;

</style>

<!DOCTYPE html>
<html>
<head>
  <title>Info</title>
</head>
<body>
   <div class="banner">
    <div class="navbar">
      <img src="./img/logoo.png" class="logo">
      <ul>
        <li><a href="index.php"><h3>Laman Utama</h3></a></li>
        <li><a href="login.php"><h3>Makanan Bungkus</h3></a></li>
        <li><a href="aduan.php"><h3>Aduan</h3></a></li>
        <li><a href="info.php"><h3>Info</h3></a></li>
      </ul>
    </div>
    <center>
    <h2 style="color:white;">-INFO DEWAN MAKAN-</h2><br><br>
    
        <img src="./img/pintu.jpeg" id="img1" onmouseover="bukak()" onmouseout="tutup()" height="370"width="560" style="border: 2px solid white;" >

    </center>

    <script>
        function bukak(){
            document.getElementById("img1").src="./img/kerusi.jpeg";
        }

        function tutup(){
            document.getElementById("img1").src="./img/pintu.jpeg";
        }
    </script><br><br>
    <center>
    <img src="./img/dots-3.png" alt="dots image"><br><br>
    </center>
    <center>
      <br>
      <table>
    <tr>
      <h3 style="color: whitesmoke;">WAKTU MAKAN ASRAMA</h3><br>
    <th></th>
    <th>Hari Persekolahan</th>
    <th>Hari Minggu</th>
    </tr>
  <tr>
    <td>Makan Pagi</td>
    <td>6.50 Pagi-7.30 Pagi</td>
    <td>7.30 Pagi-8.00 Pagi</td>
  </tr>
    <tr>
    <td>Makan Tengah Hari</td>
    <td>1.00 Petang-2.00 Petang</td>
    <td>12.30 Tengah Hari-1.30 Petang</td>
  </tr>
  <tr>
    <td>Makan Petang</td>
    <td>5.00 Petang-5.30 Petang</td>
    <td>5.00 Petang-5.30 Petang</td>
  </tr>
  <tr>
    <td>Makan Malam</td>
    <td>7.45 Malam-8.30 Malam</td>
    <td>7.45 Malam-8.30 Malam</td>
  </tr>

      </table><br><br>
      <table>
    <tr>
      <h3 style="color: whitesmoke;">WARDEN AJK BIRO MAKANAN</h3><BR>
    <th>Nama</th>
    <th>Nombor Telefon</th>
    </tr>
  <tr>
    <td>Ainatul Shahira Binti Musa</td>
    <td>+60 11-2692 6811</td>
  </tr>

      </table><br><br>
        <table>
    <tr>
      <h3 style="color: whitesmoke;">BIRO-BIRO MAKANAN</h3><BR>
    <th>Nama</th>
    <th>Nombor Telefon</th>
    </tr>
  <tr>
    <td>Muhammad Fauzan Bin Zulkifli</td>
    <td>+60 17-238 1633</td>
  </tr>
  <tr>
    <td>Nurshazulin Elliesha Binti Zulkiflee</td>
    <td>+60 10-711 7624</td>
  </tr>
  <tr>
    <td>Atif Nadhirah Binti Azimin</td>
    <td>+60 10-515 2905</td>
  </tr>
         </table>
   </div>
   </center>
   
   <div class="footer">
        <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
      </div>

</body>
</html>