<!DOCTYPE html>
<html>
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Kemaskini Makanan Bungkus</title>
</head>
      <body>

      <div class="content">
      <br><br><br>
      <center>
      <h1 style="font-size: 30px;">Kemaskini Makanan Bungkus</h1>
        <br>
        <img src="./img/dots-3.png" alt="dots image">
        <br>
      </center>
       
  <table border="0" cellpadding="5" cellspacing="2" bgcolor="white" style="padding: 50px;border-top: 3px solid orange; border-left: 3px solid orange; border-right: 3px solid orange; border-bottom: 3px solid orange; border-radius: 25px">

  <form action="bungkus.php" method="POST">
  <tr>
    <td>Nama Pelajar</td><td>:</td><td><br> <input type="text" name="nama_pelajar" required><br><br></td>
  </tr>
  <tr>
    <td>Nombor Telefon</td><td>:</td><td><br> <input type="text" name="nombor" required><br><br></td>
  </tr>
  <tr>
    <td>Dorm</td><td>:</td><td><br> <input type="text" name="dorm" required><br><br></td>
  </tr>
  <tr>
    <td colspan="5">
      <button type="submit" class="submit-btn" name="submit" value="submit" onclick="myFunction()">Hantar</button>
    </td>
</tr>
</form>

      </body>

<?php
      include('../config.php');
      if (isset($_POST['submit'])) {

      $id = $_GET['id'];
      $nama_pelajar = $_GET['nama_pelajar'];
      $nombor = $_GET['nombor'];
      $dorm = $_GET['dorm'];

      $add = mysqli_query($connect, "INSERT INTO pelajar VALUES('$id','$nama_pelajar','$nombor','$dorm')");

      header('Location: ../');
      }
?>

</html>