<?php
	include ('../config.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bungkus</title>
</head>
<body style="font-family: serif;">

	<center>
		<h2>Data Makanan Bungkus Pelajar Sakit</h2>
		<table cellpadding="5" cellspacing="0" border="1" bgcolor="white">
			<tr>
				<th>Nama Pelajar</th>
				<th>Nombor Telefon</th>
				<th>Dorm</th>
				<th colspan="2">Tindakan</th>
			</tr>

			<?php
			$papar=mysqli_query($connect, "SELECT * FROM pelajar");
			while($row=mysqli_fetch_array($papar)){

				echo "
				<tr>
				<td>".$row['nama_pelajar']."</td>
				<td>".$row['nombor']."</td>
				<td>".$row['dorm']."</td>
				<td >","<a href=delete.php?id=".$row['id']. "\"onClick=\"return confirm('Rekod ini akan dihapuskan')\">Padam</td>
				<td>","<a href=\"./kemaskini.php?id=".$row['id']. "\"Onclick=\"return confirm('Rekod ini akan dikemaskini')\">Kemaskini</td>

				</tr>
				";
			}
			?>

		</table>
		
		<p><a href="bungkus.php"><button name="tambah" class="btn" type="submit">&#43; Tambah Rekod Baru</button></a></p>

		
	</center>

		<center>
		<h2>Data Aduan Dewan Makan</h2>
		<table cellpadding="5" cellspacing="0" border="1" bgcolor="white">
			<tr>
				<th>Nama</th>
				<th>Dorm</th>
				<th>Nombor Telefon</th>
				<th>Masa</th>
				<th>Aduan</th>
				<th>Penerangan Aduan</th>
				<th>Cadangan</th>
				<th>Bukti</th>
				<th colspan="2">Tindakan</th>
			</tr>

			<?php
			$papar=mysqli_query($connect, "SELECT * FROM faduan");
			while($row=mysqli_fetch_array($papar)){

				echo "
				<tr>
				<td>".$row['nama']."</td>
				<td>".$row['dorm']."</td>
				<td>".$row['nombor']."</td>
				<td>".$row['masa']."</td>
				<td>".$row['aduan']."</td>
				<td>".$row['pAduan']."</td>
				<td>".$row['cadangan']."</td>
				<td>".$row['file']."</td>



				<td >","<a href=delete.php?id=".$row['id']. "\"onClick=\"return confirm('Rekod ini akan dihapuskan')\">Padam</td>
				<td>","<a href=\"./kemaskini.php?id=".$row['id']. "\"Onclick=\"return confirm('Rekod ini akan dikemaskini')\">Kemaskini</td>

				</tr>
				";
			}
			?>

		</table>
		<p><a href="bungkus.php"><button name="tambah" class="btn" type="submit">&#43; Tambah Rekod Baru</button></a></p>
	      </center>

     <center>
<div class="footer">
      <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
     </center>
</div>
</body>
</html>