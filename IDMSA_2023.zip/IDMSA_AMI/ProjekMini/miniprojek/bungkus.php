<style>
  *{
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

body{
  width: 100%;
  height: 100vh;
  background-image: url(./img/bg.png);
  background-size: cover;
  background-position: center;
}
.navbar{  
     width: 85%;
     margin: auto;
     padding: 35px 0;
     display: flex;
     align-items: center;
     justify-content: space-between;
}
.logo{
  width: 250px;
  cursor: pointer;
}
.navbar ul li{
  list-style: none;
  display: inline-block;
  margin: 0 20px;
  position: relative;
}
.navbar ul li a{
  text-decoration: none;
  color: white;
  text-transform: uppercase;
}
.navbar ul li::after{
  content:'';
  height: 3px;
  width: 0%;
  background: orange;
  position: absolute;
  left: 0;
  bottom: -10px;
  transition: 0.4s;
}
.navbar ul li:hover::after{
  width: 100%;
}
.content{
  width: 100%;
  position: absolute;
  top: 30%;
  transform: translateY(-50%);
  text-align: center;
  color: white;

}
/*login*/
.submit-btn{
  width: 70%;
  padding: 10px 0px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #ff105f,#ffad06);
  border: 0;
  outline: none;
  border-radius: 30px;
}
.footer{
  background-color: #FDB870;
  padding: 10px;
  text-align: center;
  margin-top: 60px;
}
.footer p{
  color: white;
}

</style>
<!DOCTYPE html>
<html>
<head>
  <title>Laman Utama</title>
</head>
<body>
   <div class="banner">
    <div class="navbar">
      <img src="./img/logoo.png" class="logo">
      <ul>
        <li><a href="index.php"><h3>Laman Utama</h3></a></li>
        <li><a href="login.php"><h3>Makanan Bungkus</h3></a></li>
        <li><a href="login2.php"><h3>Aduan</h3></a></li>
        <li><a href="info.php"><h3>Info</h3></a></li>
      </ul>
    </div>

    <div class="content">
      <br><br><br>
      <h1 style="font-size: 30px;">MAKANAN BUNGKUS</h1><br><h2>-PELAJAR SAKIT-</h2>
        <br>
        <img src="./img/dots-3.png" alt="dots image">
        <br>
    </div>
        <br><br><br><br><br>
        <center>  
        <table border="0" cellpadding="5" cellspacing="2" bgcolor="white" style="padding: 50px;border-top: 3px solid orange; border-left: 3px solid orange; border-right: 3px solid orange; border-bottom: 3px solid orange; border-radius: 25px">

  <form action="bungkus.php" method="POST">
  <tr>
    <td>Nama Pelajar</td><td>:</td><td><br> <input type="text" name="nama_pelajar" required><br><br></td>
  </tr>
  <tr>
    <td>Nombor Telefon</td><td>:</td><td><br> <input type="text" name="nombor" required><br><br></td>
  </tr>
  <tr>
    <td>Dorm</td><td>:</td><td><br> <input type="text" name="dorm" required><br><br></td>
  </tr>
<tr>
    <td colspan="5">
      <button type="submit" class="submit-btn" name="submit" value="submit" onclick="myFunction()">Hantar</button>
    </td>
</tr>
</form>
</tr>
</table>
        </center>
    </div>
   </div>
   <div class="footer">
        <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
   </div>

   <script>

     function myFunction() {
    alert("Maklumat anda telah dihantar.");
    }

   </script>

   <?php
      include('config.php');
      if(isset($_POST['submit'])){

      $nama_pelajar=$_POST['nama_pelajar'];
      $nombor=$_POST['nombor'];
      $dorm=$_POST['dorm'];
      $add = mysqli_query($connect, "INSERT INTO pelajar VALUES ('','$nama_pelajar','$nombor','$dorm')");
         header("location:index.php");
      }   
    ?>
</body>
</html>