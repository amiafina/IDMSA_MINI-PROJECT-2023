
<style>
  *{
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

body{
  width: 100%;
  height: 111vh;
  background-image: url(./img/bg.png);
  background-size: cover;
  background-position: center;
}
.navbar{  
     width: 85%;
     margin: auto;
     padding: 35px 0;
     display: flex;
     align-items: center;
     justify-content: space-between;
}
.logo{
  width: 250px;
  cursor: pointer;
}
.navbar ul li{
  list-style: none;
  display: inline-block;
  margin: 0 20px;
  position: relative;
}
.navbar ul li a{
  text-decoration: none;
  color: white;
  text-transform: uppercase;
}
.navbar ul li::after{
  content:'';
  height: 3px;
  width: 0%;
  background: orange;
  position: absolute;
  left: 0;
  bottom: -10px;
  transition: 0.5s;
}
.navbar ul li:hover::after{
  width: 100%;
}
.content{
  width: 100%;
  position: absolute;
  top: 30%;
  transform: translateY(-50%);
  text-align: center;
  color: white;

}
/*login*/
.log{
  height: 100%;
  width: 100%;
  background-position: center;
  background-size: cover;
  position: absolute;
}
.form-box{
  width: 350px;
  top: -50px;
  height: 350px;
  position: relative;
  margin: 5% auto;
  background: white;
  padding: 5px;
  overflow: hidden;
  border: 3px solid orange;
  border-radius: 35px;
}
.button-box{
  width: 220px;
  margin: 35px auto;
  position: relative;
  border-radius: 30px;
  display: flex;

}.toggle-btn{
  padding: 10px 90px;
  background: transparent;
  border: 0;
  outline: none;
  position: relative;
}
#btn{
  top: 0;
  left: 0;
  position: absolute;
  width: 220px;
  height: 100%;
  background: linear-gradient(#ff105f,#ffad06);
  border-radius: 30px;
  
}
.input-group{
  top: 100px;
  position: absolute;
  width: 250px;

}
.input-field{
  width: 100%;
  padding: 10px 0;
  margin: 6px 0;
  border-left: 0;
  border-top: 0;
  border-right: 0;
  border-bottom: 1px solid #999;
  outline: none;

}
.submit-btn{
  width: 85%;
  padding: 10px 30px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #ff105f,#ffad06);
  border: 0;
  outline: none;
  border-radius: 30px;
}
h5{
  color: grey;
  font-family: calibri;
  font-size: 15px;
}
#pelajar{
  left: 50px;
}
.footer{
  background-color: #FDB870;
  padding: 10px;
  text-align: center;
  margin-top: 500px;
}
.footer p{
  color: white;
}

</style>
<!DOCTYPE html>
<html>
<head>
  <title>Laman Utama</title>
</head>
<body>
   <div class="banner">
    <div class="navbar">
      <img src="./img/logoo.png" class="logo">
      <ul>
        <li><a href="index.php"><h3>Laman Utama</h3></a></li>
        <li><a href="login.php"><h3>Makanan Bungkus</h3></a></li>
        <li><a href="login2.php"><h3>Aduan</h3></a></li>
        <li><a href="info.php"><h3>Info</h3></a></li>
      </ul>
    </div>

    <div class="content">
      <br><br><br>
      <h1 style="font-size: 40px;">LOG MASUK</h1>
        <br>
        <img src="./img/dots-3.png" alt="dots image">
        <br>
        <center>
        <!-- logmasuk -->
        <div class="log">
          <form action="login2_backEnd.php" method="POST">
      <div class="form-box">
        <div class="button-box">
          <div id="btn"></div>
          <button type="button" class="toggle-btn">WARGA KVKS</button> 
        </div>
      <form id="faduan" class="input-group">
        <input type="text" name="username" class="input-field" placeholder="Id Pengguna" required>
        <input type="text" name="password" class="input-field" placeholder="Kata Laluan" required>
        <button type="submit" name="submit" class="submit-btn">Log Masuk</button>

        <br>
        <h5>Perhatian: Gunakan WARGAKVKS sebagai id pengguna</h5>
      </form>
      </div>
    </div>
        </center>
    </div>
   </div>
   <div class="footer">
        <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
   </div>


</body>
</html>