<?php
  include("config.php");
  session_start();

  if (isset($_POST['submit'])) {
    $usernamePost = $_POST['username'];
    $find_user_sql = mysqli_query($connect,"SELECT * FROM logmasuk2 WHERE username = '$usernamePost'");
    $find_user = mysqli_fetch_array($find_user_sql);
    $username = $find_user['username'];

    if($usernamePost == $username){
      $password = $find_user['password'];
      $passwordPost = $_POST ['password'];

      if($passwordPost == $password){
        $_SESSION['isLoggedin'] = 2;
        header("location:./aduan.php");
        
      }
      else {
        $_SESSION['error'] = "Password Pengguna Tidak Sepadan";
        header("location:./login2.php");
        
      }
    }
    else {
        $_SESSION['error'] = "Nama Pengguna Tidak Dapat Dijumpai";
        header("location:./login2.php");
        

      }
  }else {
    header("location:./login2.php");
  }
?>