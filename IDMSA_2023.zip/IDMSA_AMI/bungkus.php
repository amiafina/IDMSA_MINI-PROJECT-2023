<style>
  *{
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

body{
  width: 100%;
  height: 100vh;
  background-image: url(./img/bg.png);
  background-size: cover;
  background-position: center;
}
.navbar{  
     width: 85%;
     margin: auto;
     padding: 35px 0;
     display: flex;
     align-items: center;
     justify-content: space-between;
}
.logo{
  width: 250px;
  cursor: pointer;
}
.navbar ul li{
  list-style: none;
  display: inline-block;
  margin: 0 20px;
  position: relative;
}
.navbar ul li a{
  text-decoration: none;
  color: white;
  text-transform: uppercase;
}
.navbar ul li::after{
  content:'';
  height: 3px;
  width: 0%;
  background: orange;
  position: absolute;
  left: 0;
  bottom: -10px;
  transition: 0.4s;
}
.navbar ul li:hover::after{
  width: 100%;
}
.content{
  width: 100%;
  position: absolute;
  top: 30%;
  transform: translateY(-50%);
  text-align: center;
  color: white;

}
/*login*/
.submit-btn{
  width: 70%;
  padding: 10px 0px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #ff105f,#ffad06);
  border: 0;
  outline: none;
  border-radius: 30px;
}
.footer{
  background-color: #FDB870;
  padding: 10px;
  text-align: center;
  margin-top: 60px;
}
.footer p{
  color: white;
}

</style>
<!DOCTYPE html>
<html>
<head>
  <title>bungkus</title>
</head>
<body>
   <div class="banner">
    <div class="navbar">
      <img src="./img/logoo.png" class="logo">
      <ul>
        <li><a href="index.php"><h3>Laman Utama</h3></a></li>
        <li><a href="login.php"><h3>Makanan Bungkus</h3></a></li>
        <li><a href="aduan.php"><h3>Aduan</h3></a></li>
        <li><a href="info.php"><h3>Info</h3></a></li>
      </ul>
    </div>

    <div class="content">
      <br><br><br>
      <h1 style="font-size: 30px;">MAKANAN BUNGKUS</h1><br><h2>-PELAJAR SAKIT-</h2>
        <br>
        <img src="./img/dots-3.png" alt="dots image">
        <br>
    </div>
        <br><br><br><br><br>
        <center>  
        <table border="0" cellpadding="5" cellspacing="2" bgcolor="white" style="padding: 50px;border-top: 3px solid orange; border-left: 3px solid orange; border-right: 3px solid orange; border-bottom: 3px solid orange; border-radius: 25px">

  <form action="bungkus.php" method="POST">
  <tr>
    <td>Nama Pelajar</td><td>:</td><td><br> <input type="text" name="nama_pelajar" required><br><br></td>
  </tr>
  <tr>
    <td>Nombor Telefon</td><td>:</td><td><br> <input type="text" name="nombor" required><br><br></td>
  </tr>
  <tr>
        <td>Nama Dorm</td><td>:</td><td>
        <select id="dorm" name="dorm">
          <option value="ALI">-ALI-</option>
          <option value="Ali 1">Ali 1</option>
          <option value="Ali 2">Ali 2</option>
          <option value="Ali 3">Ali 3</option>
          <option value="Ali 4">Ali 4</option>
          <option value="Ali 5">Ali 5</option>
          <option value="Ali 6">Ali 6</option>
          <option value="Ali 7">Ali 7</option>
          <option value="Ali 8">Ali 8</option>
          <option value="UTHMAN">-UTHMAN-</option>
          <option value="Uthman 1">Uthman 1</option>
          <option value="Uthman 2">Uthman 2</option>
          <option value="Uthman 3">Uthman 3</option>
          <option value="Uthman 4">Uthman 4</option>
          <option value="Uthman 5">Uthman 5</option>
          <option value="Uthman 6">Uthman 6</option>
          <option value="Uthman 7">Uthman 7</option>
          <option value="Uthman 8">Uthman 8</option>
          <option value="SITI AISYAH">-SITI AISYAH-</option>
          <option value="Siti Aisyah 1">Siti Aisyah 1</option>
          <option value="Siti Aisyah 2">Siti Aisyah 2</option>
          <option value="Siti Aisyah 3">Siti Aisyah 3</option>
          <option value="Siti Aisyah 4">Siti Aisyah 4</option>
          <option value="Siti Aisyah 5">Siti Aisyah 5</option>
          <option value="Siti Aisyah 6">Siti Aisyah 6</option>
          <option value="Siti Aisyah 7">Siti Aisyah 7</option>
          <option value="Siti Aisyah 8">Siti Aisyah 8</option>
          <option value="SITI KHADIJAH">-SITI KHADIJAH-</option>
          <option value="Siti Khadijah 1">Siti Khadijah 1</option>
          <option value="Siti Khadijah 2">Siti Khadijah 2</option>
          <option value="Siti Khadijah 3">Siti Khadijah 3</option>
          <option value="Siti Khadijah 4">Siti Khadijah 4</option>
          <option value="Siti Khadijah 5">Siti Khadijah 5</option>
          <option value="Siti Khadijah 6">Siti Khadijah 6</option>
          <option value="Siti Khadijah 7">Siti Khadijah 7</option>
          <option value="Siti Khadijah 8">Siti Khadijah 8</option>
          <option value="SITI HAJAR">-SITI HAJAR-</option>
          <option value="Siti Hajar 1">Siti Hajar 1</option>
          <option value="Siti Hajar 2">Siti Hajar 2</option>
          <option value="Siti Hajar 3">Siti Hajar 3</option>
          <option value="Siti Hajar 4">Siti Hajar 4</option>
          <option value="Siti Hajar 5">Siti Hajar 5</option>
          <option value="Siti Hajar 6">Siti Hajar 6</option>
          <option value="Siti Hajar 7">Siti Hajar 7</option>
          <option value="Siti Hajar 8">Siti Hajar 8</option>

        </select>
  </tr><br><br>
<tr>
    <td colspan="5">
      <button type="submit" class="submit-btn" name="submit" value="submit" onclick="myFunction()">Hantar</button>
    </td>
</tr>
</form>
</tr>
</table>
        </center>
    </div>
   </div>
   <div class="footer">
        <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
   </div>

   <script>

     function myFunction() {
    alert("Maklumat anda telah dihantar.");
    }

   </script>

   <?php
      include('config.php');
      if(isset($_POST['submit'])){

      $nama_pelajar=$_POST['nama_pelajar'];
      $nombor=$_POST['nombor'];
      $dorm=$_POST['dorm'];
      $add = mysqli_query($connect, "INSERT INTO pelajar VALUES ('','$nama_pelajar','$nombor','$dorm')");
         header("location:index.php");
      }   
    ?>
</body>
</html>