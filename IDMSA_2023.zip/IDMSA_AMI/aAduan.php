<style>
  *{
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

body{
  width: 100%;
  height: 100vh;
  background-color: lightsalmon;
  background-size: cover;
  background-position: center;
}
.navbar{  
     width: 85%;
     margin: auto;
     padding: 35px 0;
     display: flex;
     align-items: center;
     justify-content: space-between;
}
.logo{
  width: 250px;

}
.navbar ul li{
  list-style: none;
  display: inline-block;
  margin: 0 20px;
  position: relative;
}
.navbar ul li a{
  text-decoration: none;
  color: white;
  text-transform: uppercase;
}
.navbar ul li::after{
  content:'';
  height: 3px;
  width: 0%;
  background: orange;
  position: absolute;
  left: 0;
  bottom: -10px;
  transition: 0.4s;
}
.navbar ul li:hover::after{
  width: 100%;
}
.content{
  width: 100%;
  position: absolute;
  top: 30%;
  transform: translateY(-50%);
  text-align: center;
  color: white;

}
/*login*/
.submit-btn{
  width: 70%;
  padding: 10px 0px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #ff105f,#ffad06);
  border: 0;
  outline: none;
  border-radius: 30px;
}
.footer{
  background-color: #FF894E;
  padding: 10px;
  text-align: center;
  margin-top: 60px;
  
}
.footer p{
  color: white;
}
</style>
<!DOCTYPE html>
<html>
<head>
  <title>aAduan</title>
</head>
<body>
   <div class="banner">
    <div class="navbar">
      <img src="./img/logoo.png" class="logo">
    </div>

    <div class="content">
      <a href="./admin/index.php" style="text-decoration: none;">Log Keluar</a>
      <br><br><br>
      <h1 style="font-size: 30px;">ADUAN</h1><br><h2>-DEWAN MAKAN-</h2>
        <br>
        <img src="./img/dots-3.png" alt="dots image">
        <br>
    </div>
        <br><br><br><br><br>
        <center>  
        <table border="0" cellpadding="5" cellspacing="2" bgcolor="white" style="padding: 50px;border-top: 3px solid orange; border-left: 3px solid orange; border-right: 3px solid orange; border-bottom: 3px solid orange; border-radius: 25px">

  <form action="aAduan.php" method="POST">
  <tr>
    <td>Nama</td><td>:</td><td><br> <input type="text" name="nama" required><br><br></td>
  </tr>
  <tr>
    <td>Dorm</td><td>:</td><td><br> <input type="text" name="dorm" required><br><br></td>
  </tr>
  <tr>
    <td>Nombor Telefon</td><td>:</td><td><br> <input type="text" name="nombor" required><br><br></td>
  </tr>
  <tr>
    <td>Masa</td><td>:</td><td>
    <div class="option">
      
      <input class="optionMasa" type="radio" name="masa" value="Makan Pagi">
      <label  for="1">Makan Pagi</label>
      <br>     
      <input class="optionMasa"  type="radio" name="masa" value="Makan Tengah Hari">
      <label for="2">Makan Tengah Hari</label>
      <br>
      <input class="optionMasa" type="radio" name="masa" value="Makan Petang">
      <label  for="3">Makan Petang</label>
      <br>
      <input class="optionMasa" type="radio" name="masa" value="Makan Malam">
      <label  for="3">Makan Malam</label>
    </div>
  </tr>
    </td>
  <tr>
    <td>Aduan</td><td>:</td><td><br>
  <div class="option">

      <input class="optionAduan" type="checkbox" name="aduan" value="Makanan Habis">
      <label  for="1">Makanan Habis</label>
      <br>     
      <input class="optionAduan" type="checkbox" name="aduan" value="Makanan Dapat Sedikit">
      <label  for="2">Makanan Dapat Sedikit</label>
      <br>     
      <input class="optionAduan"  type="checkbox" name="aduan" value="Makanan Tidak Bersih / Rosak">
      <label for="3">Makanan Tidak Bersih / Rosak</label>
      <br>
      <input class="optionAduan" type="checkbox" name="aduan" value="Pinggan / Cawan Tidak Bersih">
      <label  for="4">Pinggan / Cawan Tidak Bersih</label>
      <br>
      <input class="optionAduan" type="checkbox" name="aduan" value="Persekitaran Tidak Bersih">
      <label  for="5">Persekitaran Tidak Bersih</label>
      <br>
      <input class="optionAduan" type="checkbox" name="aduan" value="Lain-Lain">
      <label  for="6">Lain-Lain</label>
  </div>
    </td>
  </tr>
  <tr>
    <td>Penerangan<br>Aduan</td><td>:</td><td><br> <textarea rows="5" cols="30" name="pAduan"></textarea><br><br></td>
  </tr>
  <tr>
    <td>Cadangan<br>Penambahbaikkan</td><td>:</td><td><br> <textarea rows="5" cols="30" name="cadangan"></textarea><br><br></td>
  </tr>
  <tr>
    <td colspan="5">
      <button type="submit" class="submit-btn" name="submit" value="submit" onclick="myFunction()">Hantar</button>
    </td>
</tr>
</form>
</tr>
</table>
        </center>
    </div>
   </div>
   <div class="footer">
        <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
   </div>

   <?php

  include('config.php');
  if (isset($_POST['submit'])) {
  
      $nama=$_POST['nama'];
      $dorm=$_POST['dorm'];
      $nombor=$_POST['nombor'];
      $masa=$_POST['masa'];
      $aduan=$_POST['aduan'];
      $pAduan=$_POST['pAduan'];
      $cadangan=$_POST['cadangan'];
      $add = mysqli_query($connect,"INSERT INTO faduan VALUES ('','$nama','$dorm','$nombor','$masa','$aduan','$pAduan','$cadangan')");
       echo "
         <script>
         alert('Maklumat anda telah dihantar.');
         window.location.href = './admin/index.php';
         </script>
        ";}
    ?> 
</body>
</html>