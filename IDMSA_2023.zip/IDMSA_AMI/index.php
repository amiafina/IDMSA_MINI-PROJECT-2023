<style>
  *{
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

body{
  width: 100%;
  height: 100vh;
  background-image: url(./img/bg.png);
  background-size: cover;
  background-position: center;
}
.navbar{  
     width: 85%;
     margin: auto;
     padding: 35px 0;
     display: flex;
     align-items: center;
     justify-content: space-between;
}
.logo{
  width: 250px;
}
.navbar ul li{
  list-style: none;
  display: inline-block;
  margin: 0 20px;
  position: relative;
}
.navbar ul li a{
  text-decoration: none;
  color: white;
  text-transform: uppercase;

}
.navbar ul li::after{
  content:'';
  height: 3px;
  width: 0%;
  background: orange;
  position: absolute;
  left: 0;
  bottom: -10px;
  transition: 0.5s;
  
}
.navbar ul li:hover::after{
  width: 100%;
}
.content{
  width: 100%;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  text-align: center;
  color: white;
}
content h1{
  
  margin-top: 80px;
}
h2{
  color: white;
}
.content p{
  margin: 20px auto;
  font-weight: 100;
  line-height: 25px;
}
button{
  width: 200px;
  padding: 15px 0;
  text-align: center;
  margin: 20px 10px;
  font-weight: bold;
  border-radius: 25px;
  border: 2px solid orange;
  background: transparent;
  color: white;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
button a{
  text-decoration: none;
  color: white;
  font-size: 15px;
}
span{
  background: #FFB52E ;
  height: 100%;
  width: 0%;
  border-radius: 25px;
  position: absolute;
  left: 0;
  bottom: 0;
  z-index: -1;
  transition: 0.5s;
}

button:hover span{
  width: 100%;
}
button:hover{
  border: none;
}
.footer{
  background-color: #FDB870;
  padding: 10px;
  text-align: center;
  margin-top: 450px;
}
.footer p{
  color: white;
}
</style>

<!DOCTYPE html>
<html>
<head>
  <title>Laman Utama</title>

</head>
<body>
    <div class="navbar">
      <img src="./img/logoo.png" class="logo">
      <ul>
        <li><a href="index.php"><h3>Laman Utama</h3></a></li>
        <li><a href="login.php"><h3>Makanan Bungkus</h3></a></li>
        <li><a href="aduan.php"><h3>Aduan</h3></a></li>
        <li><a href="info.php"><h3>Info</h3></a></li>
        <li><a href="Alogin.php"><h3>Admin</h3></a></li>
      </ul>
    </div>

<!-- BODY1 -->
    <div class="content">
      <br><br><br>
      <h1 style="font-size: 55px;">SELAMAT DATANG KE</h1>
      <p><h3>Info Dewan Makan Sri Anggun Kolej Kediaman</h3></p>
        <img src="./img/dots-3.png" alt="dots image">
        <br>
        <br>
        <h3>|| MENU MAKANAN ASRAMA ||</h3>
        <br>
        <center>
        <button type="button"><span></span><a href="minggu1.html">MINGGU 1</a></button>
        <button type="button"><span></span><a href="minggu2.html">MINGGU 2</a></button>
        <button type="button"><span></span><a href="minggu3.html">MINGGU 3</a></button>
        <button type="button"><span></span><a href="minggu4.html">MINGGU 4</a></button>
        </center>
    </div>
   </div>

      <div class="footer">
        <p>Copyright &copy; KOLEJ KEDIAMAN KVKS</p>
      </div>

</body>
</html>